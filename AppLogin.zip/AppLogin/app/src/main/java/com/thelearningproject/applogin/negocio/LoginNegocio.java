package com.thelearningproject.applogin.negocio;
import android.support.v7.app.AppCompatActivity;

import com.thelearningproject.applogin.dao.UsuarioDAO;
import com.thelearningproject.applogin.usuario.Usuario;


/**
 * Created by Ebony Marques on 18/07/2017.
 */

public class LoginNegocio extends AppCompatActivity {

    public boolean ValidaLogin(String email, String senha) {
        UsuarioDAO persistencia = new UsuarioDAO(LoginNegocio.this);
        Usuario usuario = persistencia.retornaUsuario(email);

        // && senha.equals(usuario.getSenha())

        if (email.equals(usuario.getEmail())) {
            return true;
        } else {
            return false;
        }


    }
}
