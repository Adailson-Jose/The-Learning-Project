package com.thelearningproject.applogin;

import com.thelearningproject.applogin.MainActivity;
import com.thelearningproject.applogin.negocio.LoginNegocio;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Ebony Marques on 17/07/2017.
 */

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btLogin = (Button) findViewById(R.id.btLogin);
        btLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                TextView tLogin = (TextView) findViewById(R.id.tLogin);
                TextView tSenha = (TextView) findViewById(R.id.tSenha);
                String email = tLogin.getText().toString();
                String senha = tSenha.getText().toString();

                LoginNegocio negocio = new LoginNegocio();

                boolean resultado = negocio.ValidaLogin(email, senha);

                if (resultado) {
                    alert("Login efetuado com sucesso.");
                    Intent principal = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(principal);
                } else {
                    alert("Problema no login.");
                }

            }
        });
    }

    private void alert(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
