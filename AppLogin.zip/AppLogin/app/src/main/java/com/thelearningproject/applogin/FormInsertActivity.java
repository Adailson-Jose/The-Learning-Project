package com.thelearningproject.applogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.thelearningproject.applogin.dao.UsuarioDAO;
import com.thelearningproject.applogin.usuario.Usuario;

public class FormInsertActivity extends AppCompatActivity {
    EditText editNome, editEmail, editSenha;
    Button btCadastro;
    Usuario usuario, altusuario;
    UsuarioDAO usuariodao;
    long retorno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forminsert);

        Intent i = getIntent();
        altusuario = (Usuario)i.getSerializableExtra("usuario-enviado");
        usuario = new Usuario();
        usuariodao = new UsuarioDAO(FormInsertActivity.this);

        editNome = (EditText)findViewById(R.id.editNome);
        editEmail = (EditText)findViewById(R.id.editEmail);
        editSenha = (EditText)findViewById(R.id.editSenha);
        btCadastro = (Button)findViewById(R.id.btCadastro);

        if(altusuario != null) {
            btCadastro.setText("Alterar");
        } else {
            btCadastro.setText("Salvar");
        }

        btCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usuario.setNome(editNome.getText().toString());
                usuario.setEmail(editEmail.getText().toString());
                usuario.setSenha(editSenha.getText().toString());

                if(btCadastro.getText().toString().equals("Salvar")) {
                    retorno = usuariodao.cadastrar(usuario);

                    if(retorno == -1) {
                        alert("Erro ao cadastrar.");
                    } else {
                        alert("Cadastro efetuado com sucesso.");
                    }
                } else {
                    alert("Algo errado está acontecendo.");
                }

                finish();
            }
        });

    }

    private void alert(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
