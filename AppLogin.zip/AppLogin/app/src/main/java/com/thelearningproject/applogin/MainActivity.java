package com.thelearningproject.applogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.thelearningproject.applogin.dao.UsuarioDAO;
import com.thelearningproject.applogin.usuario.Usuario;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listaVisivel;
    Button btNovoCadastro;
    Usuario usuario;
    UsuarioDAO usuariodao;
    ArrayList<Usuario> arrayusuarios;
    ArrayAdapter<Usuario> adapterusuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaVisivel = (ListView)findViewById(R.id.Usuarios);
        btNovoCadastro = (Button)findViewById(R.id.btNovoCadastro);

        btNovoCadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FormInsertActivity.class);
                startActivity(i);
            }
        });
    }

    public void lista() {
        usuariodao = new UsuarioDAO(MainActivity.this);
        arrayusuarios = usuariodao.retornaUsuarios();
        usuariodao.close();

        if(listaVisivel != null) {
            adapterusuarios = new ArrayAdapter<Usuario>(MainActivity.this, android.R.layout.simple_list_item_1, arrayusuarios);
            listaVisivel.setAdapter(adapterusuarios);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        lista();
    }
}
