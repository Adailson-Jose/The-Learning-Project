package com.thelearningproject.applogin.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ArrayAdapter;

import com.thelearningproject.applogin.usuario.Usuario;

import java.util.ArrayList;

/**
 * Created by Ebony Marques on 17/07/2017.
 */

public class UsuarioDAO extends SQLiteOpenHelper {
    private static final String NOME_BANCO = "BDUsuario";
    private static final int VERSION = 1;
    private static final String TABELA = "usuarios";
    private static final String ID = "id";
    private static final String NOME = "nome";
    private static final String EMAIL = "email";
    private static final String SENHA = "senha";

    public UsuarioDAO(Context context) {
        super(context, NOME_BANCO, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABELA + "(" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NOME + " TEXT, " +
                EMAIL + " TEXT, " +
                SENHA + " TEXT);";

        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS " + TABELA;
        db.execSQL(sql);
        onCreate(db);
    }

    public long cadastrar(Usuario usuario) {
        ContentValues values = new ContentValues();
        long retorno;

        values.put(NOME, usuario.getNome());
        values.put(EMAIL, usuario.getEmail());
        values.put(SENHA, usuario.getSenha());

        retorno = getWritableDatabase().insert(TABELA, null, values);

        return retorno;
    }

    public ArrayList<Usuario> retornaUsuarios() {
        String[] colunas = {ID, NOME, EMAIL};
        Cursor cursor = getWritableDatabase().query(TABELA, colunas, null, null, null, null, null, null);
        ArrayList<Usuario> listausuarios = new ArrayList<Usuario>();

        while (cursor.moveToNext()) {
            Usuario usuario = new Usuario();
            usuario.setId(cursor.getInt(0));
            usuario.setNome(cursor.getString(1));
            usuario.setEmail(cursor.getString(2));

            listausuarios.add(usuario);
        }

        return listausuarios;
    }

    public Usuario retornaUsuario(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor objeto = db.rawQuery("SELECT * FROM " + TABELA + " WHERE email = '" + email + "'", null);
        objeto.close();
        Usuario usuario = new Usuario();
        usuario.setId(objeto.getInt(0));
        usuario.setNome(objeto.getString(1));
        usuario.setEmail(objeto.getString(2));

        return usuario;
    }
}
