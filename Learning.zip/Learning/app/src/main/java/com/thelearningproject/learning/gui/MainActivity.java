package com.thelearningproject.learning.gui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.thelearningproject.learning.R;
import com.thelearningproject.learning.negocio.Sessao;

public class MainActivity extends AppCompatActivity {
    private Sessao sessao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sessao = new Sessao(this);

        if (sessao.getLogado() == null) {
            logout();
        }

        TextView exibir = (TextView) findViewById(R.id.textoexibir);
        String texto = "Bem-vindo, " + sessao.getLogado() + ".";
        exibir.setText(texto);

        Button botlogout = (Button) findViewById(R.id.botlogout);
        botlogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void logout() {
        sessao.setLogado(null);
        finish();

        startActivity(new Intent(MainActivity.this, LoginActivity.class));
    }
}