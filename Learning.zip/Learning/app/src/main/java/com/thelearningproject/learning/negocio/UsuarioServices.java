package com.thelearningproject.learning.negocio;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.thelearningproject.learning.dao.UsuarioDAO;
import com.thelearningproject.learning.dominio.Usuario;
import com.thelearningproject.learning.gui.CadastroActivity;

/**
 * Created by Ebony Marques on 18/07/2017.
 */

public class UsuarioServices extends AppCompatActivity {

    private static UsuarioServices sInstance;
    private UsuarioDAO banco = new UsuarioDAO(UsuarioServices.this);

    public UsuarioServices(Context context){
        this.banco = UsuarioDAO.getInstance(context);
    }

    public static UsuarioServices getsInstance(Context context){
        if(sInstance == null){
            sInstance = new UsuarioServices(context);
        }
        return sInstance;
    }

    public Usuario validaLogin(String email, String senha) {
        Usuario usuario = banco.retornaUsuario(email, senha);
        return usuario;
    }

    public boolean verifica(Usuario novo){
        Usuario usuario = banco.verificaEmail(novo.getEmail());
        if (usuario != null){
            return false;
        }else{
            return true;
        }
    }

    public Usuario inserirUsuario(Usuario usuario){
        if (this.verifica(usuario)){
            banco.inserir(usuario);
            return usuario;
        }else{
            return null;
        }
    }

}
