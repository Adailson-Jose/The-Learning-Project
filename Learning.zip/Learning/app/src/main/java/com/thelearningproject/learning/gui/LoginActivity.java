package com.thelearningproject.learning.gui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.thelearningproject.learning.R;
import com.thelearningproject.learning.dao.UsuarioDAO;
import com.thelearningproject.learning.dominio.Usuario;
import com.thelearningproject.learning.negocio.Sessao;
import com.thelearningproject.learning.negocio.UsuarioServices;

public class LoginActivity extends Activity {
    private Button entrar;
    private Button cadastrar;
    private EditText txtemail;
    private EditText txtsenha;
    private Sessao sessao;
    private UsuarioDAO banco = new UsuarioDAO(LoginActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        banco = new UsuarioDAO(this);
        sessao = new Sessao(this);

        entrar = (Button) findViewById(R.id.botentrar);
        cadastrar = (Button) findViewById(R.id.botnovocadastro);
        txtemail = (EditText) findViewById(R.id.txtemail);
        txtsenha = (EditText) findViewById(R.id.txtsenha);

        entrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                String email = txtemail.getText().toString();
                String senha = txtsenha.getText().toString();

                UsuarioServices negocio = new UsuarioServices(LoginActivity.this);
                Usuario resultado = negocio.validaLogin(email, senha);

                if (resultado != null) {
                    sessao.setLogado(email);
                    Intent principal = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(principal);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Dados inválidos.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        cadastrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent principal = new Intent(LoginActivity.this, CadastroActivity.class);
                startActivity(principal);
                finish();
            }
        });
    }
}
