package com.thelearningproject.learning.negocio;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Ebony Marques on 20/07/2017.
 */

public class Sessao {
    SharedPreferences preferencias;
    SharedPreferences.Editor editor;
    Context contexto;

    public Sessao(Context contexto) {
        this.contexto = contexto;
        preferencias = contexto.getSharedPreferences("Learning", Context.MODE_PRIVATE);
        editor = preferencias.edit();
    }

    public void setLogado(String email) {
        editor.putString("usuario", email);
        editor.commit();
    }

    public String getLogado() {
        return preferencias.getString("usuario", null);
    }
}