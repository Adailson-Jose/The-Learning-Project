package com.thelearningproject.learning.gui;

import android.os.Bundle;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.thelearningproject.learning.R;
import com.thelearningproject.learning.dominio.Usuario;
import com.thelearningproject.learning.negocio.UsuarioServices;

public class CadastroActivity extends AppCompatActivity {
    private Button botcadastrar;
    private EditText txtnome;
    private EditText txtemail;
    private EditText txtsenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        botcadastrar = (Button) findViewById(R.id.botacaocadastrar);
        txtnome = (EditText) findViewById(R.id.txtusuariocad);
        txtemail = (EditText) findViewById(R.id.txtemailcad);
        txtsenha = (EditText) findViewById(R.id.txtsenhacad);

        botcadastrar.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                UsuarioServices negocio = UsuarioServices.getsInstance(getBaseContext());
                String nome = txtnome.getText().toString();
                String email = txtemail.getText().toString();
                String senha = txtsenha.getText().toString();
                Usuario usuario = new Usuario();
                usuario.setEmail(email);
                usuario.setNome(nome);
                usuario.setSenha(senha);

                Toast.makeText(getApplicationContext(), email, Toast.LENGTH_SHORT).show();

                if (negocio.inserirUsuario(usuario) != null){
                    startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                    Toast.makeText(getApplicationContext(), "Cadastro efetuado", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(), "E-mail já cadastrado", Toast.LENGTH_SHORT).show();
                }
            }


        });

    }
}
